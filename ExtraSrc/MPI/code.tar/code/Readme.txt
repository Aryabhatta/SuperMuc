Version with following changes in original:
1. Loop interchange for relax & copy
2. Modified residual calculation
3. removed copy operation
4. changes in misc.c to copy the boundary
